from proconfig.widgets.base import WIDGETS, CATEGORIES
from flask import Flask
from flask import Flask, request, jsonify, send_from_directory
import os
import time
import json
import flask
from flask import Flask, Response, request, jsonify, abort, send_from_directory, render_template
import threading
import torch
import queue
from typing import Literal
import json
import enum
from filelock import FileLock
import uuid
from datetime import datetime
from easydict import EasyDict
from proconfig.widgets.base import WIDGETS
from proconfig.utils.misc import convert_unserializable_display, hash_dict
from proconfig.utils.pytree import tree_map
from proconfig.core import Workflow
from proconfig.core.constant import return_breakpoint_cache_dir

import gc

gc.enable()

# define the app and some basic settings

app = Flask(
    __name__, 
    instance_relative_config=True, 
    static_folder='web-build', 
    template_folder='web-build',
    static_url_path=''
)

flask.json.provider.DefaultJSONProvider.sort_keys = False

os.environ["PROCONFIG_PROJECT_ROOT"] = os.environ.get("PROCONFIG_PROJECT_ROOT", "data")

PROJECT_ROOT = os.environ["PROCONFIG_PROJECT_ROOT"]

print("current project root:", PROJECT_ROOT)

UPLOAD_FOLDER = os.path.join("input") # to be compatible with ComfyUI
OUTPUT_FOLDER = "output"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)
WORKFLOW_SAVE_ROOT =  os.path.join(PROJECT_ROOT, "workflow")
APP_SAVE_ROOT =  os.path.join(PROJECT_ROOT, "app")
MODEL_DIR = "models"
CUSTOM_WIDGETS_DIR = "custom_widgets"

CUSTOM_WIDGETS_STATUS_PATH = os.path.join(CUSTOM_WIDGETS_DIR, "widgets_status.json")
MODELS_STATUS_PATH = os.path.join(MODEL_DIR, "model_status.json")

os.environ["MODEL_DIR"] = MODEL_DIR
os.environ["MODELS_STATUS_PATH"] = MODELS_STATUS_PATH


os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(WORKFLOW_SAVE_ROOT, exist_ok=True)
os.makedirs(APP_SAVE_ROOT, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

endpoint_prefix = "/api/workflow"

# initialize the 

def initialize_envs():
    if not os.path.isfile("settings.json"):
        json.dump({"model_location": "models", "envs": {}}, open("settings.json", "w"))
    env = json.load(open("settings.json"))
    # os.environ["MODEL_DIR"] = env.get("model_location", "models")
    # os.environ["MODELS_STATUS_PATH"] = os.path.join(os.environ["MODEL_DIR"], "model_status.json")
    if not os.path.isfile(os.environ["MODELS_STATUS_PATH"]):
        json.dump({}, open(os.environ["MODELS_STATUS_PATH"], "w"))
    if not os.path.isfile(CUSTOM_WIDGETS_STATUS_PATH):
        json.dump({}, open(CUSTOM_WIDGETS_STATUS_PATH, "w"))
        
    for k, v in env["envs"].items():
        os.environ[k] = str(v)
        
initialize_envs()

def get_file_times(file_path):
    try:
        # Get the creation time
        creation_time = os.path.getctime(file_path)
        # Get the last modification time
        modification_time = os.path.getmtime(file_path)

        # Convert the timestamps to human-readable format
        creation_time_str = time.ctime(creation_time)
        modification_time_str = time.ctime(modification_time)

        return creation_time_str, modification_time_str, modification_time
    except Exception as e:
        print(f"An error occurred: {e}")
        return None, None
    
    
@app.route('/')
def home():
    return render_template("app.html")

@app.route('/app')
def app_page():
    return render_template("app.html")

@app.route('/workflow')
def workflow_page():
    return render_template("workflow.html")

@app.route('/app/detail')
def app_detail_page():
    return render_template("app/detail.html")

@app.route('/workflow/detail')
def workflow_detail_page():
    return render_template("workflow/detail.html")

@app.route('/about')
def about():
    return "About Page"
from flask import Flask, Response, request, jsonify, abort, send_from_directory, render_template
import os
import json
from filelock import FileLock
from proconfig.widgets.imagen_widgets.utils.dependency_checker import check_dependency
from proconfig.core import Automata
from proconfig.runners.runner import Runner
from pydantic import BaseModel
from typing import Dict, Any, Literal, List, Optional
import argparse
import json
import queue
import time
from flask import Flask, Response, request, jsonify, abort, send_from_directory, render_template
import threading
from flask import Flask, request, jsonify
from datetime import datetime
import uuid
import os
import traceback
import torch
from proconfig.utils.misc import convert_unserializable_display, hash_dict
from proconfig.utils.pytree import tree_map
from proconfig.core.chat import ServerMessage, MessageComponentsContainer, MessageComponentsButton, \
    MessageComponentsButtonAction, MessageComponentsTypeEnum, MessageInputSetting, EmbedObj, \
    EmbedObjStatus, EmbedObjType
    
from .base import app, APP_SAVE_ROOT, WORKFLOW_SAVE_ROOT

# app related
@app.route(f'/api/app/save', methods=['POST'])
def save_app():
    data = request.get_json()
    
    try:
        flow_id = data["app_id"]
        backend = data["automata"]
        frontend = {
            k: data[k]
            for k in ["config", "reactflow"] 
        }
        save_root = f"{APP_SAVE_ROOT}/{flow_id}/latest"
        os.makedirs(save_root, exist_ok=True)
        
        with FileLock(os.path.join(save_root, "lock.lock")):
            json.dump(backend, open(f"{save_root}/automata.json", "w"), indent=2)
            json.dump(frontend, open(f"{save_root}/reactflow.json", "w"), indent=2)
    
        response = {
            "success": True
        }
    except Exception as e:
        response = {
            "success": False,
            "message": str(e)
        }
    return jsonify(response)

@app.route('/api/app/get_automata', methods=['POST'])
def get_automata():
    data = request.get_json()
    flow_id = data["app_id"]
    version = data.get("version_name", "latest")
    save_root = os.path.join(APP_SAVE_ROOT, flow_id, version)
    proconfig_file = os.path.join(save_root, "automata.json")
    if os.path.isfile(proconfig_file):
        proconfig = json.load(open(proconfig_file))
    else:
        proconfig = {}
    response = {
        "data": proconfig
    }
    return jsonify(response)

@app.route('/api/app/get_flow', methods=['POST'])
def get_app_flow():
    data = request.get_json()
    flow_id = data["app_id"]
    version = data.get("version_name", "latest")
    save_root = os.path.join(APP_SAVE_ROOT, flow_id, version)
    flow_file = os.path.join(save_root, "reactflow.json")
    if os.path.isfile(flow_file):
        response = json.load(open(flow_file))
    else:
        response = {}
    # get the metadata
    metadata_file = os.path.join(save_root, "metadata.json")
    if os.path.isfile(metadata_file):
        metadata = json.load(open(metadata_file))
    else:
        metadata = {}
    response["metadata"] = metadata
    return jsonify(response)


# export
@app.route('/api/app/export', methods=['POST'])
def export_app():
    data = request.get_json()
    
    try:
        automata_path = os.path.join(APP_SAVE_ROOT, data["app_id"], data["version_name"], "automata.json")
        metadata_path = os.path.join(APP_SAVE_ROOT, data["app_id"], data["version_name"], "metadata.json")
        metadata = json.load(open(metadata_path))
        automata = json.load(open(automata_path))
        dependency_results = check_dependency(automata)
        # get the workflows
        workflows = {}
        for workflow_id in dependency_results["workflow_ids"]:
            workflow_path = os.path.join(WORKFLOW_SAVE_ROOT, workflow_id, "proconfig.json") # NOTE: the workflow_id includes the version_name
            workflow = json.load(open(workflow_path))
            workflows[workflow_id] = workflow
            
        results = {
            "data": {
                "automata": automata,
                "workflows": workflows,
                "metadata": metadata,
                "dependency": {
                    "models": dependency_results["models"],
                    "widgets": dependency_results["widgets"]
                }
            },
            "success": True,
            "message": ""
        }
    
    except Exception as e:
        error_message = str(traceback.format_exc())
        results = {
            "data": {},
            "success": False,
            "message_detail": error_message,
            "message": str(e),
        }

    return jsonify(results)


# app run

from proconfig.utils.misc import convert_unserializable_display, hash_dict
from proconfig.utils.pytree import tree_map
from proconfig.core.chat import ServerMessage, MessageComponentsContainer, MessageComponentsButton, \
    MessageComponentsButtonAction, MessageComponentsTypeEnum, MessageInputSetting, EmbedObj, \
    EmbedObjStatus, EmbedObjType



class ProConfigEvent(BaseModel):
    target_state: str = ""
    automata: dict = None
    sess_id: str = ""
    payload: Dict[str, Any] = {}
    
class RunAppRequest(BaseModel):
    form_data: Dict[str, Any] = {}
    session_id: str = ""
    embedObjs: List[Any] = None
    
    buttonId: str = ""
    messageType: int # 1: TEXT,2: VOICE,15: BUTTON_INTERACTION
    
    text: str = None
    # automata: Optional[Automata] = None
    message: str = None
    

sess_id_to_automata = {}
sess_states = {}
environ = {}

os.environ["PROCONFIG_PROJECT_ROOT"] = "data"

def generate_sess_id():
    return str(uuid.uuid1())

EVENT_MAPPING_KEY = "EVENT_MAPPING"
CHAT_MESSAGE = "CHAT_MESSAGE"

@app.route('/api/app/init_bot', methods=['POST'])
def init_bot():
    data = request.get_json()
    try:
        automata = Automata.model_validate(data['automata'])
        session_id = generate_sess_id()
        sess_id_to_automata[session_id] = automata
        
        return_data = {
            "session_id": session_id
        }
    except Exception as e:
        error_message = str(traceback.format_exc())
        return_data = {
            "session_id": None,
            "message": error_message
        }

    return jsonify(return_data)
    
    
# SSE
clients = []
@app.route('/api/app/run', methods=['POST', 'GET'])
def app_run():
    event_data = request.get_data()
    event_data = json.loads(event_data)
    event_data = RunAppRequest.model_validate(event_data)
    
    automata = sess_id_to_automata[event_data.session_id]
        
    sess_id = event_data.session_id
    sess_state = sess_states.get(sess_id, {})
    sess_state["message_count"] = sess_state.get("message_count", 0)
    
    # decide the event_name
    if event_data.messageType == 15:
        event_name = event_data.buttonId
    elif event_data.messageType == 1:
        event_name = "CHAT"
        # build the form data
        event_data.form_data[CHAT_MESSAGE] = event_data.text
    else:
        event_name = None
    
    target_state = automata.initial if event_name is None else sess_state[EVENT_MAPPING_KEY][event_name]["target_state"]
    
    sess_state["current_state"] = target_state
        
    def generate(client_queue):
        while True:
            try:
                message = client_queue.get(timeout=1)
                yield message
                if message.split('\n')[0].startswith("event: state_exit"):
                    torch.cuda.empty_cache()
                    break
            except queue.Empty:
                data = json.dumps({})
                message = f"event: heartbeat\ndata: {data}\n\n"
                yield message
                continue
            
    client_queue = queue.Queue()
    
    while True:
        if len(clients) == 0:
            clients.append(client_queue)
            break
        else:
            time.sleep(2)
            print("waiting...")
        
    threading.Thread(target=execute_automata, args=(client_queue, automata, environ, event_data.form_data, sess_id, sess_state)).start()
    # return Response(generate(client_queue), mimetype='text/event-stream')
    resp = Response(generate(client_queue), mimetype='text/event-stream')
    headers = [
        ('Connection', 'keep-alive'),
        ('Content-Encoding', 'none'),
        ('Cache-Control', 'no-cache'),
        ('Access-Control-Allow-Origin', '*'),
        ('Access-Control-Allow-Methods', '*'),
        ('Access-Control-Allow-Headers', '*'),
        ('Access-Control-Allow-Credentials', 'true')
    ]
    for k, v in headers:
        resp.headers[k] = v
    return resp


type_map = {
    "text": "string"
}
def build_form_schema(target_inputs):
    if len(target_inputs) == 0:
        return None, MessageInputSetting()
    
    properties = {}
    required = []
    
    canInputText = False 
    canInputAudio = False
    canUploadFile = False
    for k, v in target_inputs.items():
        if v.user_input:
            required.append(k)
        properties[k] = {
            "name": getattr(v, "name"),
            "type": type_map.get(v.type, v.type),
            "description": v.description,
            "default": v.default_value
        }
        if v.choices:
            properties[k]["enum"] = v.choices
            
        if v.source == "IM":
            if v.type == "audio":
                canInputAudio = True
            elif v.type in ["file", "text_file"]:
                canUploadFile = True
            elif v.type in ["text", "string"]:
                canInputText = True
        
    json_schema = {
        "properties": properties,
        "required": required
    }
    
    inputSetting = MessageInputSetting(
        canInputText=canInputText,
        canInputAudio=canInputAudio,
        canUploadFile=canUploadFile
    )
    return json_schema, inputSetting
        
RenderTypeMap = {
    "image": EmbedObjType.IMAGE,
    "audio": EmbedObjType.AUDIO,
}
def parse_server_message(session_id, render, event_mapping, message_count):
    # build the componentContainer
    buttons = []
    for button_count, button in enumerate(render.get("buttons", [])):
        buttonId = f'BUTTON_{button_count}'
        schema, _ = build_form_schema(event_mapping[buttonId]["target_inputs"])
        
        if schema is not None:
            actions = [MessageComponentsButtonAction(
                formSchema=schema
            )]
        else:
            actions = []
        content = {
            "text": button['content'],
        }
        message_component_button = MessageComponentsButton(
            content=content,
            buttonId=buttonId,
            actions=actions,
            payload=event_mapping[buttonId]["target_inputs_transition"],
        )
        buttons.append(
            MessageComponentsContainer(
                type=MessageComponentsTypeEnum.BUTTON,
                button=message_component_button,
            )
        )
        
    if "CHAT" in event_mapping:
        _, inputSetting = build_form_schema(event_mapping["CHAT"]["target_inputs"])
    else:
        inputSetting = MessageInputSetting(
            canInputText=False,
            canInputAudio=False,
            canUploadFile=False
        )
        
    componentContainer = MessageComponentsContainer(
        type=MessageComponentsTypeEnum.CONTAINER,
        components=buttons,
    )
    
    # build images
    objs = []
    
    for media_key, media_type in RenderTypeMap.items():
        if media_key in render:
            if not type(render[media_key]) == list:
                render[media_key] = [render[media_key]]
            for media in render[media_key]:
                ext = media.rsplit(".", 1)[-1]
                media_obj = EmbedObj(
                    id=None,
                    status=EmbedObjStatus.DONE,
                    type=media_type,
                    extensionName=ext,
                    url=media
                )
                objs.append(media_obj)
            
    current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    server_message = ServerMessage(
        session_id=session_id,
        id=str(message_count),
        text=render.get("text", "") or "",
        status="DONE",
        type="TEXT",
        createdDateUnix=current_time,
        updatedDateUnix=current_time,
        embedObjs=objs,
        componentContainer=componentContainer,
        inputSetting=inputSetting
    )
    return server_message

def execute_automata(client_queue, automata, environ, payload, sess_id, sess_state):
    def callback(
        event_type=Literal['app_start', 'app_end', 'state_start', 'state_end', 'state_exit', 'task_start', 'task_end'],
        inputs=None,
        outputs=None, 
        create_time=None, 
        finish_time=None, 
        task_status: Literal['start', 'succeeded', 'failed'] = None,
        task_name=None,
        progress=None,
        **kwargs
    ):
        data = {
            "input": tree_map(convert_unserializable_display, inputs),
            "output": tree_map(convert_unserializable_display, outputs),
            "node_id": task_name,
            "create_time": create_time,
            "finish_time": finish_time,
            "node_status": task_status,
            **kwargs
        }
        json_data = json.dumps(data)
        message = f"event: {event_type}\ndata: {json_data}\n\n"
        client_queue.put(message)
    
    create_time = time.time()
    runner = Runner(callback=callback)
    try:
        sess_state, render, event_mapping = runner.run_automata(automata, sess_state, environ, payload)
        sess_state[EVENT_MAPPING_KEY] = event_mapping
        sess_states[sess_id] = sess_state
        server_message = parse_server_message(sess_id, render, event_mapping, sess_state["message_count"])
        sess_state["message_count"] += 1
        callback('state_exit', server_message=server_message.model_dump(), create_time=create_time, finish_time=time.time(), task_status="succeeded")
    except Exception as e:
        error_message_detail = traceback.format_exc()
        error_message = str(e)
        callback('state_exit', outputs={"error_message": str(error_message), "error_message_detail": str(error_message_detail)}, create_time=create_time, finish_time=time.time(), task_status="failed")
    finally:
        if len(clients) > 0:
            clients.pop()
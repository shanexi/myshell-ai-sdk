# OpenProConfig

## Install
```
conda create -n proconfig python==3.10
conda activate proconfig
conda install pytorch==2.3.0 torchvision torchaudio pytorch-cuda=12.1 -c pytorch -c nvidia
pip3 install -e .
```

## Usage

launch the backend API:
```
CUDA_VISIBLE_DEVICES=0 python main.py --config configs/imagen/stable_cascade_controlnet.json
```

Run the CLI renderer (for debugging) in another process
```
python proconfig/renderers/cli_renderer.py 
```

## Git Submodule usage
add a custom node from remote
```
git submodule add git@github.com:comfyanonymous/ComfyUI.git 
```

add multiple custom nodes (installed by ComfyUI-Manager)
```
bash dev_tools/update_submodules.sh
```

git submodule update --init --recursive



## New Environment
### build the poetry yaml
```
conda create -n proconfig-new python==3.10
conda activate proconfig-new
pip install poetry
poetry init
poetry add ...
```

### use in a brand-new environment
```
conda create -n proconfig-new python==3.10
conda activate proconfig-new
pip install -e .
```

### Run the backend
```
python servers/main.py --port 8099 --device 0
```

from proconfig.utils.cli_utils import prompt
import json5
from runners.automata_runner_flask_sse import RunAppRequest, ServerMessage
import requests
from prompt_toolkit.completion import WordCompleter
import argparse

import sseclient
import requests
import json5


def run_see(url, payload):
    response = requests.post(url, stream=True, json=payload)
    client = sseclient.SSEClient(response)

    for event in client.events():
        print(event.event, event.data)
    return ServerMessage(**json5.loads(event.data)['server_message'])
        
        
def post_event(url, payload):
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        result = response.json()
        return result
    else:
        return None
# class RunAppRequest(BaseModel):
#     form_data: Dict[str, Any] = {}
#     session_id: str = ""
#     embedObjs: List[Any] = None
#     text: str = None # for now we can use this to pass the button id
#     automata: Optional[Automata] = None
#     event_name: str = None

# def post_event(event_data: ProConfigEvent = None, endpoint="run"):
#     if event_data is not None:
#         event_data = event_data.model_dump()
#     response = requests.post(f"{host}/{endpoint}", json=event_data)
#     if response.status_code == 200:
#         result = response.json()
#         if endpoint == "run":
#             return ProConfigData.model_validate(result)
#         return result
#     else:
#         return None

def format_print(data: ServerMessage):
    # print text
    print("[text]", data.text)
    print("[images]", [item.url for item in data.embedObjs if item.type == "MESSAGE_METADATA_TYPE_IMAGE_FILE"])
    print("[buttons]:", [button['button']['content']['text'] for button in return_data.componentContainer.components])
        
        
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", type=str, default="http://127.0.0.1:8099")
    parser.add_argument("--config")
    args = parser.parse_args()
    host = args.host
    automata_config = json5.load(open(args.config))
    
    url_init = f"{args.host}/api/app/init_bot"
    url = f"{args.host}/api/app/run"
    
    # first run init
    sess_id = post_event(url_init, {"automata": automata_config})["session_id"]
    
    event_data = {
        'session_id': sess_id,
        "messageType": -1
    } # empty to start
    return_data = run_see(url, event_data)
    # proconfig = post_event(endpoint="get_proconfig")
    
    while True:
        # render = return_data.render
        format_print(return_data)
        # render["buttons"] = render.get("buttons", [])
        
        # check interactable
        interactable = False
        has_chat = return_data.inputSetting and any(return_data.inputSetting.model_dump().values())
        has_button = len(return_data.componentContainer.components) > 0
        interactable = has_button or has_chat
        
        if interactable:
            # button_names = [button["content"] for button in render["buttons"]]
            # name_to_event = {button["content"]: button["on_click"] if type(button["on_click"]) == str else button["on_click"]["event"] for button in render["buttons"]}
            
            # has_button = "BUTTON_0" in return_data.event_mapping
            # has_chat = "CHAT" in return_data.event_mapping
            if has_button and has_chat:
                info_message = "Click a Button or Chat: "
            elif has_button:
                info_message = "Click a Button: "
            else:
                info_message = "Chat: "
                
            if has_button:
                button_names = [button['button']['content']['text'] for button in return_data.componentContainer.components]
            else:
                button_names = []
                
            while True:
                button_name = prompt(info_message, completer=WordCompleter(button_names))
                if has_chat or (button_name in button_names):
                    break
                
            if button_name in button_names:
                button_id = button_names.index(button_name)
                button_id = f"BUTTON_{button_id}"
            else:
                button_id = "CHAT"
                chat_message = button_name
                
                
                
            # event_name = name_to_event[button_name]
            # event_mapping = return_data.event_mapping[button_id]
            # # target_state_name = event_mapping["target_state"]
            # target_inputs = event_mapping["target_inputs"]
            # target_inputs_transition = event_mapping["target_inputs_transition"]
            
            # print("received target_inputs_transition", target_inputs_transition)
            
            # # find possible inputs
            # local_transitions = proconfig["states"][return_data.current_state]['transitions']
            # global_transitions = proconfig['transitions']
            # next_state_name = local_transitions.get(event_name, None)
            # next_state_name = next_state_name or global_transitions.get(event_name, None)
            # if next_state_name is None:
            #     import pdb; pdb.set_trace()
            # next_state_inputs = proconfig["states"][next_state_name]["inputs"]
            
            request_data = {
                "session_id": sess_id,
            }
            
            if button_id != "CHAT":
                button_index = button_names.index(button_name)
                button_component = return_data.componentContainer.components[button_index]['button']
                form_schema = button_component['actions'][0]['formSchema']
                payload = {}
                for k, v in form_schema['properties'].items():
                    if k in form_schema['required']:
                        prompt_string = f"{k}:\n"
                        if v["description"]:
                            prompt_string += f"    [Description]: {v['description']}\n"
                        if v["default"]:
                            prompt_string += f"    [Default Value]: {v['default_value']}\n"
                        prompt_string += "    [User Input]: "
                        if "enums" in v:
                            while True:
                                payload[k] = prompt(prompt_string, completer=WordCompleter(v["enums"]))
                                if payload[k] in v["choices"]:
                                    break
                        else:
                            payload[k] = prompt(prompt_string)
                payload = {**payload, **button_component['payload']}
                request_data["form_data"] = payload
                request_data["messageType"] = 15
                request_data["buttonId"] = button_id
            else:
                payload = {}
                request_data["text"] = chat_message
                request_data["messageType"] = 1
                
            # add the target inputs transition
    # form_data: Dict[str, Any] = {}
    # session_id: str = ""
    # embedObjs: List[Any] = None
    # text: str = None # for now we can use this to pass the button id
    # automata: Optional[Automata] = None
    # event_name: str = None
            # request_data = {
            #     "form_data": payload,
            #     "session_id": sess_id,
            #     "event_name"
            # # }
            # event_data = ProConfigEvent(target_state=target_state_name, sess_id=sess_id, payload=payload)
            return_data = run_see(url, request_data)
        else:
            print("App End")
            break

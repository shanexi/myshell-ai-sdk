from proconfig.widgets.base import BaseWidget, WIDGETS
from proconfig.widgets.imagen_widgets.base import ImagenWidgetCategory
from pydantic import Field, WithJsonSchema
import torch
from typing import Literal, Annotated, List, Any, Union
from pydantic.fields import FieldInfo
from annotated_types import Ge, Le
import os
import time
import re
import glob
import logging
import traceback

Ellipsis = ...
# from proconfig.widgets.imagen_widgets.utils.custom_types import *
from nodes import init_builtin_extra_nodes, load_custom_node
init_builtin_extra_nodes()
from nodes import NODE_DISPLAY_NAME_MAPPINGS, NODE_CLASS_MAPPINGS

var_type_map = {
    "INT": "int",
    "FLOAT": "float",
    "IMAGE": "IMAGE",
    "STRING": "str",
    "CONDITIONING": "CONDITION",
    "BOOLEAN": "bool",
    "*": "Any",
    # some hard code
    "INT,FLOAT": "Union[int, float]",
    "INT:seed": "int",
}

native_types = ['str', 'int', 'float', 'bool']

field_kwargs_map = {
    "min": "ge",
    "max": "le",
    "step": "multiple_of",
    "multiline": "multiline",
    "placeholder": "placeholder",
    "image_upload": "image_uplaod",
    "video_upload": "video_upload",
    "audio_upload": "audio_upload",
    "dynamicPrompts": "dynamicPrompts",
    "round": "round",
    "padding": "padding"
}

ignore_fields = [
    "pysssss.autocomplete",
    "pysssss.binding"
]

def init_external_custom_nodes():
    """
    Initializes the external custom nodes.

    This function loads custom nodes from the specified folder paths and imports them into the application.
    It measures the import times for each custom node and logs the results.

    Returns:
        None
    """
    base_node_names = set(NODE_CLASS_MAPPINGS.keys())
    node_paths = ["proconfig/widgets/imagen_widgets/library/comfy_custom_nodes"]
    node_import_times = []
    for custom_node_path in node_paths:
        possible_modules = os.listdir(os.path.realpath(custom_node_path))
        if "__pycache__" in possible_modules:
            possible_modules.remove("__pycache__")

        for possible_module in possible_modules:
            module_path = os.path.join(custom_node_path, possible_module)
            if os.path.isfile(module_path) and os.path.splitext(module_path)[1] != ".py": continue
            if module_path.endswith(".disabled"): continue
            time_before = time.perf_counter()
            success = load_custom_node(module_path, base_node_names)
            node_import_times.append((time.perf_counter() - time_before, module_path, success))

    if len(node_import_times) > 0:
        logging.info("\nImport times for custom nodes:")
        for n in sorted(node_import_times):
            if n[2]:
                import_message = ""
            else:
                import_message = " (IMPORT FAILED)"
            logging.info("{:6.1f} seconds{}: {}".format(n[0], import_message, n[1]))
        logging.info("")

def add_suffixes(input_list):
    count = {}
    result = []
    
    for item in input_list:
        if item in count:
            count[item] += 1
            result.append(f"{item}_{count[item]}")
        else:
            count[item] = 1
            result.append(item)
    
    # Second pass to correct the first occurrence of duplicates
    for i in range(len(result)):
        item = result[i]
        if item in count and count[item] > 1:
            result[i] = f"{item}_1"
            count[item] -= 1
    
    return result

def to_valid_variable_name(input_string):
    # Replace dots and spaces with underscores
    input_string = input_string.replace('.', '_').replace(' ', '_')
    
    # Remove all non-ASCII characters
    input_string = input_string.encode('ascii', 'ignore').decode('ascii')
    
    # Remove any characters that are not alphanumeric or underscores
    input_string = re.sub(r'[^0-9a-zA-Z_]', '', input_string)
    
    # Ensure the variable name does not start with a digit
    if input_string and input_string[0].isdigit():
        input_string = '_' + input_string
    
    input_string = input_string.lower()
    if input_string == '':
        return 'result'
    return input_string

# def build_inputs_schema(NodeClass: ImagePadForOutpaint):
#     model_fields = {}
#     for variable_category, variables in NodeClass.INPUT_TYPES().items():
#         hidden = not variable_category == "required"
#         for var_name, var_schema in variables.items():
#             if type(var_schema) == str:
#                 var_schema = ("STRING", {"default": var_schema})
#             var_type = var_schema[0]
#             if len(var_schema) > 1:
#                 field = var_schema[1]
#             else:
#                 field = {}
                
#             if type(field) == str:
#                 field = {"default": field}

#             if type(var_type) == list:
#                 if "default" not in field:
#                     field["default"] = var_type[0]
#                 var_type = "Literal" + str(var_type)
#             elif var_type in var_type_map:
#                 var_type = var_type_map[var_type]
#             else:
#                 var_type = var_type
                
#             if hidden and "default" not in field:
#                 field["default"] = None
#             if "default" not in field:
#                 default_value = "..."
#             elif type(field["default"]) == str:
#                 default_value = f"\"{field['default']}\""
#             else:
#                 default_value = field['default']
#             field_kwargs = {}
#             for k, v in field.items():
#                 if k in ["default", "display"]:
#                     continue
#                 if k not in field_kwargs_map:
#                     print(f"warning: cannot find {k}")
#                 else:
#                     new_k = field_kwargs_map[k]
#                     if k == "step" and type(v) == float:
#                         continue
#                     field_kwargs[new_k] = v
#             if hidden:
#                 field_kwargs["hidden"] = True
#             field_str = ", ".join([f"{k}={v}" for k, v in field_kwargs.items()])
#             field = eval(f"Field({default_value}, {field_str})\n")
#             field.annotation = eval(var_type)
#             model_fields[var_name] = field
#     return model_fields
# IMAGE = Annotated[str, WithJsonSchema({'type': 'IMAGE'})]
# MASK = Annotated[str, WithJsonSchema({'type': 'IMAGE'})]

@WIDGETS.register_module(name="ComfyUI/Reroute")
class ComfyRerouteWidget(BaseWidget):
    NAME = "ComfyUI/Reroute"
    CATEGORY = "ComfyUI Nodes/utils"
    class InputsSchema(BaseWidget.InputsSchema):
        input_var_0: Any = None
        
    class OutputsSchema(BaseWidget.OutputsSchema):
        output_var: Any
        
    @torch.no_grad()
    def execute(self, environ, config: dict = {}):
        return {"output_var": config.input_var_0}

default_value_map = {}
node_instances = {}

def convert_var_type(var_type):
    pass

def build_comfy_widget(node_name, NodeID, NodeClass) -> BaseWidget:
    return_dict = {}
    
    types_lines = ''
    
    total_lines = f"""
@WIDGETS.register_module(name="ComfyUI/{NodeID}")
class ComfyWidget(BaseWidget):
    NAME = "{node_name}"
    CATEGORY = "ComfyUI Nodes/{NodeClass.CATEGORY.split('/')[0]}"
    class InputsSchema(BaseWidget.InputsSchema):
"""
    var_name_map = {}
    count = 0
    if NodeID in ["LoadImage"]:
        is_upload = True
    else:
        is_upload = False
    
    for variable_category, variables in NodeClass.INPUT_TYPES().items():
        hidden = variable_category == "hidden"
        for var_name, var_schema in variables.items():
            count += 1
            # if type(var_schema) == str:
            #     var_schema = ("STRING", {"default": var_schema})
            if type(var_schema) not in [tuple, list]:
                # print(var_schema, NodeClass)
                var_schema = (var_schema, {"default": None})
                
            var_type = var_schema[0]
                
            
            if len(var_schema) > 1:
                field = var_schema[1]
            else:
                field = {}
                
            if type(field) == str:
                field = {"default": field}

            if type(var_type) == tuple:
                var_type = list(var_type)
                
            choices = None
            if type(var_type) == list:
                if "default" not in field:
                    if len(var_type) > 0:
                        field["default"] = var_type[0]
                    else:
                        field["default"] = ...

                if len(var_type) > 0:
                    choices = var_type
                    var_type = "Literal" + str(var_type)
                else:
                    var_type = "str"
                    
                
            elif var_type in var_type_map:
                var_type = var_type_map[var_type]
            else:
                var_type = var_type
                
            if type(var_type) == str and var_type not in native_types:
                # types_lines += f"{var_type} = Annotated[str, WithJsonSchema({{'type': '{var_type}'}})]\n"
                if var_type not in globals():
                    globals()[var_type] =  Annotated[Any, WithJsonSchema({'type': var_type})]
#                 IMAGE = Annotated[str, WithJsonSchema({'type': 'IMAGE'})]
# MASK = Annotated[str, WithJsonSchema({'type': 'IMAGE'})]

            if (variable_category != "required") and "default" not in field:
                default_value = None
            elif "default" not in field:
                default_value = ...
            else:
                default_value = field['default']
                
            field_kwargs = {}
            for k, v in field.items():
                if k in ignore_fields:
                    continue
                if k in ['min', 'max'] and var_type == 'int':
                    v = int(v)
                if k in ["default", "display"]:
                    continue
                if k not in field_kwargs_map:
                    print(f"warning: cannot find {k}")
                    field_kwargs_map[k] = k
                else:
                    new_k = field_kwargs_map[k]
                    if k == "step" and type(v) == float:
                        continue
                    field_kwargs[new_k] = v
                
            if is_upload:
                var_type = "str"
                if choices is not None:
                    field_kwargs["choices"] = choices

            if hidden:
                field_kwargs["hidden"] = True
            field_str = ", ".join([f"{k}={v}" if type(v) != str else f'{k}="{v}"' for k, v in field_kwargs.items()])
            
            new_var_name = var_name.replace('.', '_').replace(' ', '_').lower()
            new_var_name = new_var_name.replace("+", "pos_").replace("-", "neg_")
            
            if new_var_name in native_types:
                new_var_name = new_var_name + "_input"
            if new_var_name.startswith("_"):
                new_var_name = "input" + new_var_name
            var_name_map[new_var_name] = var_name
            default_value_new = f"\'{default_value}\'" if type(default_value) == str else default_value
            if default_value_new == 'euler':
                import pdb; pdb.set_trace()
            default_value_map[count] = default_value
            line = f"        {new_var_name}: {var_type} = Field(default_value_map[{count}], {field_str})\n"
            total_lines += line
    # output schema
    output_line = ""
    return_dict_line = ""
    

    if not hasattr(NodeClass, "RETURN_NAMES"):
        RETURN_NAMES = add_suffixes(NodeClass.RETURN_TYPES)
    else:
        RETURN_NAMES = NodeClass.RETURN_NAMES
    RETURN_TYPES = NodeClass.RETURN_TYPES
    added_output = False
    if len(RETURN_NAMES) == 0:
        RETURN_TYPES = ('*',)
        RETURN_NAMES = ('result',)
        added_output = True
      
    output_count = 0  
    for return_name, return_type in zip(RETURN_NAMES, RETURN_TYPES):
        return_name = to_valid_variable_name(return_name)
        if type(return_type) == list:
            if len(return_type) > 0:
                return_type = "Literal" + str(return_type)
            else:
                return_type = "str"
        else:
            return_type = var_type_map.get(return_type, return_type)
        output_line += f"        {return_name}: {return_type}\n"
        if type(return_type) == str and return_type not in native_types:
            if return_type not in globals():
                globals()[return_type] =  Annotated[Any, WithJsonSchema({'type': return_type})]
                # types_lines += f"{return_type} = Annotated[str, WithJsonSchema({{'type': '{return_type}'}})]\n"
        return_dict_line += f"            \"{return_name}\": outputs[{output_count}],\n"
        output_count += 1
    
    function_name = NodeClass.FUNCTION
    node_instances[node_name] = NodeClass()
    output_line1 = f'outputs = node_instances[\"{node_name}\"].{function_name}(**kwargs)'
    total_lines += f"""
        pass
    class OutputsSchema(BaseWidget.OutputsSchema):
{output_line}
        pass
    
    @torch.no_grad()
    def execute(self, environ, config: dict = {{}}):
        config = self.InputsSchema.model_validate(config)
        kwargs = config.model_dump()
        
        if {is_upload}:
            for k, v in kwargs.items():
                if type(v) == str and v.startswith("input/"):
                    kwargs[k] = v[len("input/"):]
            
        try:
            {output_line1}
        except Exception as e:
            logging.error(e, exc_info=True)
            print(traceback.format_exc())
            raise e
        if type(outputs) == dict:
            if 'result' in outputs:
                outputs = outputs['result']
            elif {added_output}:
                # convert for save_images
                if 'ui' in outputs and 'images' in outputs['ui']:
                    outputs = [item['type'] + '/' + item['filename'] for item in outputs['ui']['images']]
                outputs = [outputs]
        return_dict = {{
{return_dict_line}        }}
        return return_dict
return_dict['result'] = ComfyWidget
"""
    # total_lines = types_lines + total_lines
    try:
        exec(total_lines)
    except Exception as e:
        print(total_lines)
        print(traceback.format_exc())
        import pdb; pdb.set_trace()
    if is_upload:
        print(total_lines)
    return return_dict['result']

init_external_custom_nodes()

for NodeID, NodeClass in NODE_CLASS_MAPPINGS.items():
    try:
        WidgetClass = build_comfy_widget(NODE_DISPLAY_NAME_MAPPINGS.get(NodeID, NodeID), NodeID, NodeClass)
    except Exception as e:
        logging.warning(f"failed to load {NodeID}, \n {e}")
    
# build the widgets
if __name__ == '__main__':
    # print(add_suffixes(['image', 'image', 'mask', 'model', 'clip', 'vae', 'model']))
    
    # for NodeID, NodeClass in NODE_CLASS_MAPPINGS.items():
    #     WidgetClass = build_comfy_widget(NODE_DISPLAY_NAME_MAPPINGS.get(NodeID, NodeID), NodeClass)
    #     print(WidgetClass.InputsSchema.model_json_schema())
    
    print(field_kwargs_map)
    import pdb; pdb.set_trace()
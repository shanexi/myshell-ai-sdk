import torch
from typing import Any, Literal, Optional, List
from pydantic import Field, BaseModel

from proconfig.widgets.base import BaseWidget, WIDGETS
from proconfig.widgets.language_models.base import LLMWidgetCategory

# import instructor
import os
from openai import OpenAI
from pydantic import BaseModel, Field, create_model
import base64

TypeMap = {
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "list": list,
    "dict": dict,
}


class FunctionParameter(BaseModel):
    """
    The parameter for the function.
    """
    name: str = Field(..., description="The name of the parameter.")
    type: str = Field(..., description="The type of the parameter.")
    default: Optional[Any] = Field(
        None, description="The default value of the parameter.")
    description: Optional[str] = Field(
        None, description="The description of the parameter.")
    
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        base64_image = base64.b64encode(image_file.read()).decode("utf-8")
    return f"data:image/png;base64,{base64_image}"

@WIDGETS.register_module()
class GPTWidget(BaseWidget):
    NAME = "GPT"
    CATEGORY = LLMWidgetCategory.GPT
    
    class InputsSchema(BaseWidget.InputsSchema):
        model: Literal["gpt-3.5-turbo", "gpt-4o", "gpt-4o-mini", "gpt-4-turbo"] = "gpt-4o"
        system_prompt: Optional[str] = ""
        user_prompt: Optional[str] = ""
        input_image: Optional[str] = None
        temperature: Optional[float] = 0.7
        top_p: Optional[float] = 1.0
        max_tokens: Optional[int] = None
        stream: Optional[bool] = False
        presence_penalty: Optional[float] = 0.0
        frequency_penalty: Optional[float] = 0.0

        # function_schema: Optional[Any] = Field(
        #     None, description="The schema for the function. For advanced users only.")
        # function_name: str = Field(
        #     None, description="The name of the function. For basic users.")
        # function_description: str = Field(
        #     None, description="The description of the function. For basic users.")
        # function_parameters: List[FunctionParameter] = Field(
        #     [], description="The parameters of the function. For basic users.")
    
    class OutputsSchema(BaseWidget.OutputsSchema):
        reply: str
        
    @torch.no_grad()
    def execute(self, environ, config):
        try:
            client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        except Exception as e:
            print(f'[Warning] Initiate OpenAI error: {e}')
        """
        Execute the LLM function.
        """
        # Load the config
        # if config.function_name is not None:
        #     # Parse the function parameters
        #     parameters = {}
        #     for parameter in config.function_parameters:
        #         parameter = FunctionParameter.model_validate(parameter)
        #         parameters[parameter.name] = (TypeMap[parameter.type], Field(
        #             parameter.default if parameter.default is not None else Ellipsis, description=parameter.description))
        #     # Create the model
        #     function_schema = create_model(
        #         config.function_name,
        #         __doc__=config.function_description,
        #         **parameters,
        #     )
        # else:
        #     function_schema = None
        config.system_prompt = config.system_prompt or ""
        config.user_prompt = config.user_prompt or ""
        
        if config.input_image is not None:
            assert config.model in ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo"], "the gpt model does not support image input"
            user_prompt = [
                {"type": "text", "text": config.user_prompt},
                {"type": "image_url", "image_url": {"url": encode_image(config.input_image)}}
            ]
        else:
            user_prompt = config.user_prompt
            
        
        output = client.chat.completions.create(
            model=config.model,
            temperature=config.temperature,
            top_p=config.top_p,
            max_tokens=config.max_tokens,
            stream=config.stream,
            presence_penalty=config.presence_penalty,
            frequency_penalty=config.frequency_penalty,
            # response_model=function_schema,
            messages=[
                {"role": "system", "content": config.system_prompt},
                {"role": "user", "content": user_prompt},
            ]
        )
        result = output.model_dump()
        return_dict = {'reply': result['choices'][0]['message']['content']}
        print(return_dict)
        return return_dict